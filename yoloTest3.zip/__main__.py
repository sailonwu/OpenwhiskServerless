def main(args):
    import os
    from time import time
    import json
    from ultralytics import YOLO
    start = time()
    source = args.get("url", None)
    model = YOLO("/models/yolov8n.pt")
    downlodpic = time()
    ini_latency = downlodpic - start
    results = model(source)
    finish = time()
    run_latency = finish - downlodpic

    # 从环境变量获取 OpenWhisk activation ID
    activationId = os.environ.get('__OW_ACTIVATION_ID', 'unknown')  # 修改这里

    return {
        "result": str([json.loads(r.to_json()) for r in results]),
        "activationId": activationId,
        "begintime":start,
        "endtime":finish,
        "initime":ini_latency,
        "runtime":run_latency
    }
